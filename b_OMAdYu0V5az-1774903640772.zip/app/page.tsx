"use client"

import { useState } from "react"
import { Sidebar, ViewType } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { DashboardView } from "@/components/dashboard/dashboard-view"
import { OrdersView } from "@/components/dashboard/orders-view"
import { TablesView } from "@/components/dashboard/tables-view"
import { ProductsView } from "@/components/dashboard/products-view"
import { InventoryView } from "@/components/dashboard/inventory-view"
import { LoginForm } from "@/components/auth/login-form"
import { RegisterForm } from "@/components/auth/register-form"

type AuthState = "login" | "register" | "authenticated"

interface User {
  email: string
  restaurantName: string
}

export default function Dashboard() {
  const [authState, setAuthState] = useState<AuthState>("login")
  const [user, setUser] = useState<User | null>(null)
  const [activeView, setActiveView] = useState<ViewType>("dashboard")

  const handleLogin = (email: string) => {
    setUser({ email, restaurantName: "Bella Italia" })
    setAuthState("authenticated")
  }

  const handleRegister = (data: { restaurantName: string; email: string }) => {
    setUser({ email: data.email, restaurantName: data.restaurantName })
    setAuthState("authenticated")
  }

  const handleLogout = () => {
    setUser(null)
    setAuthState("login")
    setActiveView("dashboard")
  }

  if (authState === "login") {
    return (
      <LoginForm
        onLogin={handleLogin}
        onSwitchToRegister={() => setAuthState("register")}
      />
    )
  }

  if (authState === "register") {
    return (
      <RegisterForm
        onRegister={handleRegister}
        onSwitchToLogin={() => setAuthState("login")}
      />
    )
  }

  const renderView = () => {
    switch (activeView) {
      case "dashboard":
        return <DashboardView restaurantName={user?.restaurantName} />
      case "orders":
        return <OrdersView />
      case "tables":
        return <TablesView />
      case "products":
        return <ProductsView />
      case "inventory":
        return <InventoryView />
      case "settings":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-semibold text-foreground">Settings</h1>
            <p className="text-muted-foreground mt-2">Settings page coming soon.</p>
          </div>
        )
      default:
        return <DashboardView restaurantName={user?.restaurantName} />
    }
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar
        activeView={activeView}
        onViewChange={setActiveView}
        onLogout={handleLogout}
        restaurantName={user?.restaurantName}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto">
          {renderView()}
        </main>
      </div>
    </div>
  )
}
