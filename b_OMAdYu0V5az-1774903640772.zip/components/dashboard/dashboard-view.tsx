"use client"

import { StatCard } from "./stat-card"
import { RevenueChart } from "./revenue-chart"
import { CategoryChart } from "./category-chart"
import { InfoCard } from "./info-card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { CheckCircle2, Users, UtensilsCrossed, Clock } from "lucide-react"

interface DashboardViewProps {
  restaurantName?: string
}

export function DashboardView({ restaurantName = "Bella Italia" }: DashboardViewProps) {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">
            Welcome back!
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Here&apos;s what&apos;s happening at {restaurantName} today.
          </p>
        </div>
        <Select defaultValue="today">
          <SelectTrigger className="w-36 rounded-xl">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="this-week">This week</SelectItem>
            <SelectItem value="this-month">This month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="space-y-4">
          <StatCard
            title="Today's Revenue"
            value="$ 2,458"
            change="12.5%"
            changeType="positive"
            subtitle="vs yesterday"
            highlighted
          />
          <StatCard
            title="Active Tables"
            value="8/12"
            change="2"
            changeType="positive"
            subtitle="Tables occupied"
          />
        </div>

        <div className="space-y-4">
          <StatCard
            title="Orders Today"
            value="47"
            change="8.3%"
            changeType="positive"
            subtitle="vs yesterday"
          />
          <StatCard
            title="Avg. Order Value"
            value="$ 52.30"
            change="3.2%"
            changeType="positive"
            subtitle="vs last week"
          />
        </div>

        <RevenueChart />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <InfoCard
          icon={<UtensilsCrossed className="w-5 h-5 text-muted-foreground" />}
          value="12"
          label="pending orders"
          description={
            <>
              5 orders{" "}
              <span className="text-amber-500">need attention</span> in the kitchen.
            </>
          }
        />
        <InfoCard
          icon={<Clock className="w-5 h-5 text-muted-foreground" />}
          value="18"
          label="min avg wait"
          description={
            <>
              Average wait time is{" "}
              <span className="text-green-500">3 min faster</span> than usual.
            </>
          }
        />
        <CategoryChart />
      </div>
    </div>
  )
}
